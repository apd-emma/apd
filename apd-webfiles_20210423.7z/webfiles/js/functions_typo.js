// BIBLIOGRAPHY //

function checkBiblioParams(title,doctype) {
	var submitval;
	var missingArr = new Array();
	if(title=='' && doctype!='Rezension') {
		missingArr.push('Title');
	}
	if(doctype=='') {
		missingArr.push('Document type');
	}
	var missingStr = missingArr.join(', ');
	if((title=='' && doctype!='Rezension') || doctype=='') {
		alert('Fill in missing information: ' + missingStr);
		submitval=0;
	}
	else {
		submitval=1;
	}
	if(submitval==1) {
		return true;
	}
	else {
		return false;
	}
}

function confirmDelete() {
	var submitval;
	submitval=confirm('Sure you want to DELETE this title?');
	if(submitval==1) {
		document.getElementById('action').value='delete';
		return true;
	}
	else {
		return false;
	}	
}

function setDoctype(dt) {
	document.getElementById('doctype').value=dt;
}

function setSerial(serial) {
	document.getElementById('serial').value=serial;
}

function addNewSerial(serial) {
	setSerial(serial);
	document.getElementById('serialselect').options[0].text=serial;
	document.getElementById('serialselect').selectedIndex=0;
}

function editSerial(serial) {
	document.getElementById('serialcorr').value=serial;
	document.getElementById('serialselect').options[0].text=serial;
	document.getElementById('serialselect').selectedIndex=0;
}

function setJournal(journal) {
	document.getElementById('journal').value=journal;
}

function addNewJournal(journal) {
	setJournal(journal);
	document.getElementById('journalselect').options[0].text=journal;
	document.getElementById('journalselect').selectedIndex=0;
}

function editJournal(journal) {
	document.getElementById('journalcorr').value=journal;
	document.getElementById('journalselect').options[0].text=journal;
	document.getElementById('journalselect').selectedIndex=0;
}

function setSpecialissue(specialissue) {
	document.getElementById('specialissue').value=specialissue;
}

function addNewSpecialissue(specialissue) {
	setSpecialissue(specialissue);
	document.getElementById('specialissueselect').options[0].text=specialissue;
	document.getElementById('specialissueselect').selectedIndex=0;
}

function editSpecialissue(specialissue) {
	document.getElementById('specialissuecorr').value=specialissue;
	document.getElementById('specialissueselect').options[0].text=specialissue;
	document.getElementById('specialissueselect').selectedIndex=0;
}

function setSupertitle(id,supertitle) {
	document.getElementById('supertitleid').value=id.replace('edvol','');
}

function setReviewtitle(id,reviewtitle) {
	document.getElementById('reviewtitleid').value=id;
}

function setInDerIslamBiblio(idib) {
	document.getElementById('in_derislambiblio').value=idib;
}

function setScan(sc) {
	document.getElementById('scan').value=sc;
}

function setKeywordIndex(keywordsel,index) {
	var keywordindex=keywordsel.replace('select','index');
	document.getElementById(keywordindex).value=index;
}

function setKeywordIndices() {
	if(document.getElementById('keyword1index').value!='') {
		document.getElementById('keyword1select').selectedIndex=document.getElementById('keyword1index').value;
	}
	if(document.getElementById('keyword2index').value!='') {
		document.getElementById('keyword2select').selectedIndex=document.getElementById('keyword2index').value;
	}
	if(document.getElementById('keyword3index').value!='') {
		document.getElementById('keyword3select').selectedIndex=document.getElementById('keyword3index').value;
	}
}

function addNewKeyword(kw) {
	document.getElementById('newkeyword').value=kw;
	addKeywords();
	document.getElementById('newkeyword').value='';
}

function addKeywords() {
	if(document.getElementById('keywords').value!='') {
		var keywordarr = document.getElementById('keywords').value.split("; ");
	}
	else {
		var keywordarr = new Array();
	}
	if(document.getElementById('newkeyword').value!='') {
		var newkeywordsarr = document.getElementById('newkeyword').value.split("; ");
		for(i=0;i<newkeywordsarr.length;i++) {
			keywordarr.push(newkeywordsarr[i]);
		}
	}
	for(i=0;i<document.editform["keywordoptionsadd[]"].length;i++) {
		var included = keywordarr.includes(document.editform["keywordoptionsadd[]"][i].value);
		if(document.editform["keywordoptionsadd[]"][i].selected==true && included==false) { 
			keywordarr.push(document.editform["keywordoptionsadd[]"][i].value);
			keywordarr.sort();
		}
	}
	document.getElementById('keywords').value=keywordarr.join("; ");
	document.getElementById('keywordsnew').value=keywordarr.join("; ");
}

function dropKeywords() {
	if(document.getElementById('keywords').value!='') {
		var keywordarr = document.getElementById('keywords').value.split("; ");
	}
	else {
		var keywordarr = new Array();
	}
	for(i=0;i<document.editform["keywordoptionsdrop[]"].length;i++) {
			var included = keywordarr.includes(document.editform["keywordoptionsdrop[]"][i].value);
		if(document.editform["keywordoptionsdrop[]"][i].selected==true && included==true) { 
			var dropindex = keywordarr.indexOf(document.editform["keywordoptionsdrop[]"][i].value);
			keywordarr.splice(dropindex,1);
			keywordarr.sort();
		}
	}
	document.getElementById('keywords').value=keywordarr.join("; ");
	document.getElementById('keywordsnew').value=keywordarr.join("; ");
}

// PALEO //

function setAnglehabagroups(anglehabagroups,explication,anglehabagroupsimg) {
	document.getElementById('anglehabagroups').value=anglehabagroups;
	document.getElementById('anglehabagroupsexplic').value=explication;
	document.getElementById('anglehabagroupsimgparam').value='img/lspaleosearch/png/'+anglehabagroupsimg+'.png';
	if(anglehabagroupsimg!='') {
		document.getElementById('anglehabagroupsbtn').value=explication;
		document.getElementById('anglehabagroupsbtn').innerHTML=explication;
		document.getElementById('anglehabagroupsimg').src='img/lspaleosearch/png/'+anglehabagroupsimg+'.png';
		document.getElementById('anglehabagroupsimg').style.visibility='visible';
		//document.getElementById('anglehabagroupsimg').setAttribute('width','70');
	}
}

function setSlanting(slanting,explication,slantingimg) {
	document.getElementById('slanting').value=slanting;
	document.getElementById('slantingexplic').value=explication;
	document.getElementById('slantingimgparam').value='img/lspaleosearch/png/'+slantingimg+'.png';
	if(slantingimg!='') {
		document.getElementById('slantingbtn').value=explication;
		document.getElementById('slantingbtn').innerHTML=explication;
		document.getElementById('slantingimg').src='img/lspaleosearch/png/'+slantingimg+'.png';
		document.getElementById('slantingimg').style.visibility='visible';
		//document.getElementById('slantingimg').setAttribute('width','70');
	}
}

function setBaseline(baseline,explication,baselineimg) {
	document.getElementById('baseline').value=baseline;
	document.getElementById('baselineexplic').value=explication;
	document.getElementById('baselineimgparam').value='img/lspaleosearch/png/'+baselineimg+'.png';
	if(baselineimg!='') {
		document.getElementById('baselinebtn').value=explication;
		document.getElementById('baselinebtn').innerHTML=explication;
		document.getElementById('baselineimg').src='img/lspaleosearch/png/'+baselineimg+'.png';
		document.getElementById('baselineimg').style.visibility='visible';
		//document.getElementById('baselineimg').setAttribute('width','70');
	}
}

function setLineori(lineori,explication,lineoriimg) {
	document.getElementById('lineori').value=lineori;
	document.getElementById('lineoriexplic').value=explication;
	document.getElementById('lineoriimgparam').value='img/lspaleosearch/png/'+lineoriimg+'.png';
	if(lineoriimg!='') {
		document.getElementById('lineoribtn').value=explication;
		document.getElementById('lineoribtn').innerHTML=explication;
		document.getElementById('lineoriimg').src='img/lspaleosearch/png/'+lineoriimg+'.png';
		document.getElementById('lineoriimg').style.visibility='visible';
		//document.getElementById('lineoriimg').setAttribute('width','180');
	}
}

function setAnglehalinegroups(angle,index) {
	document.getElementById('anglehalinegroups').value=angle;
	if(angle!='') {
		document.getElementById('anglehalinegroupsindex').value=index;
	}
	else {
		document.getElementById('anglehalinegroupsindex').value=0;
	}
}

function setLongname(longname,index) {
	document.getElementById('longname').value=angle;
	if(angle!='') {
		document.getElementById('longnameindex').value=index;
	}
	else {
		document.getElementById('longnameindex').value=0;
	}
}

function resetPaleoFilters(mode) {
	document.getElementById('anglehabagroups').value='';
	document.getElementById('anglehabagroupsexplic').value='';
	document.getElementById('anglehabagroupsimgparam').value='';
	document.getElementById('anglehabagroupsimg').src='';
	document.getElementById('anglehabagroupsimg').style.visibility='hidden';
	document.getElementById('anglehabagroupsbtn').value='choose value';
	document.getElementById('anglehabagroupsbtn').innerHTML='choose value';
	document.getElementById('anglehalinegroups').value='';
	document.getElementById('anglehalinegroupsindex').value='';
	document.paleoform.anglehalinegroupsselect.selectedIndex=0;
	document.getElementById('longname').value='';
	document.getElementById('longnameindex').value='';
	document.paleoform.longnameselect.selectedIndex=0;
	document.getElementById('slanting').value='';
	document.getElementById('slantingexplic').value='';
	document.getElementById('slantingimgparam').value='';
	document.getElementById('slantingimg').src='';
	document.getElementById('slantingimg').style.visibility='hidden';
	document.getElementById('slantingbtn').value='choose value';
	document.getElementById('slantingbtn').innerHTML='choose value';
	document.getElementById('baseline').value='';
	document.getElementById('baselineexplic').value='';
	document.getElementById('baselineimgparam').value='';
	document.getElementById('baselineimg').src='';
	document.getElementById('baselineimg').style.visibility='hidden';
	document.getElementById('baselinebtn').value='choose value';
	document.getElementById('baselinebtn').innerHTML='choose value';
	document.getElementById('lineori').value='';
	document.getElementById('lineoriexplic').value='';
	document.getElementById('lineoriimgparam').value='';
	document.getElementById('lineoriimg').src='';
	document.getElementById('lineoriimg').style.visibility='hidden';
	document.getElementById('lineoribtn').value='choose value';
	document.getElementById('lineoribtn').innerHTML='choose value';
	document.getElementById('resultdiv').innerHTML='';
}

function setPaleoIndices() {
	// anglehalinegroups:
	anglehalinegroupsindex=document.getElementById('anglehalinegroupsindex').value;
	if(anglehalinegroupsindex!='') {
		document.paleoform.anglehalinegroupsselect.selectedIndex=anglehalinegroupsindex;
	}
	else {
		document.paleoform.anglehalinegroupsselect.selectedIndex=0;
	}
	// longname:
	longnameindex=document.getElementById('longnameindex').value;
	if(longnameindex!='') {
		document.paleoform.longnameselect.selectedIndex=longnameindex;
	}
	else {
		document.paleoform.longnameselect.selectedIndex=0;
	}
}

function resetLineori() {
	document.getElementById('lineori').value='';
	document.getElementById('lineoriexplic').value='';
	document.getElementById('lineoriimgparam').value='';
	document.getElementById('lineoriimg').src='';
	document.getElementById('lineoriimg').style.visibility='hidden';
	document.getElementById('lineoribtn').value='choose value';
	document.getElementById('lineoribtn').innerHTML='choose value';
	document.getElementById('resultdiv').innerHTML='';
}

function resetSlanting() {
	document.getElementById('slanting').value='';
	document.getElementById('slantingexplic').value='';
	document.getElementById('slantingimgparam').value='';
	document.getElementById('slantingimg').src='';
	document.getElementById('slantingimg').style.visibility='hidden';
	document.getElementById('slantingbtn').value='choose value';
	document.getElementById('slantingbtn').innerHTML='choose value';
	document.getElementById('resultdiv').innerHTML='';
}

function resetBaseline() {
	document.getElementById('baseline').value='';
	document.getElementById('baselineexplic').value='';
	document.getElementById('baselineimgparam').value='';
	document.getElementById('baselineimg').src='';
	document.getElementById('baselineimg').style.visibility='hidden';
	document.getElementById('baselinebtn').value='choose value';
	document.getElementById('baselinebtn').innerHTML='choose value';
	document.getElementById('resultdiv').innerHTML='';
}

function resetAnglehabagroups() {
	document.getElementById('anglehabagroups').value='';
	document.getElementById('anglehabagroupsexplic').value='';
	document.getElementById('anglehabagroupsimgparam').value='';
	document.getElementById('anglehabagroupsimg').src='';
	document.getElementById('anglehabagroupsimg').style.visibility='hidden';
	document.getElementById('anglehabagroupsbtn').value='choose value';
	document.getElementById('anglehabagroupsbtn').innerHTML='choose value';
	document.getElementById('resultdiv').innerHTML='';
}

// TEXT and LAYOUT //

/*
function textlayoutwindow(laid,stfid,ed) {
	tlwindow = window.open("textlayoutdetails.jsp?laid="+laid+"&stfid="+stfid+"&ed="+ed+"","newwindow","width=600,height=800,left=0,top=0,scrollbars=yes,resizable=yes,menubar=no");
	tlwindow.focus();
}
*/

function setOrderParam(orderby) {
	document.orderbyform.orderby.value=orderby;
	//alert(orderby);
	document.orderbyform.submit();
}

function setOrderByIndex() {
	if(document.orderbyform.orderby.value=='FORMAL type and subtype' || document.orderbyform.orderby.value=='') {
		document.orderbyform.orderbysel.selectedIndex=0;
	}
	else {
		document.orderbyform.orderbysel.selectedIndex=1;
	}
}

function setDocEditParam(docedit) {
	document.orderbyform.docedit.value=docedit;
	//alert(orderby);
	document.orderbyform.submit();
}

function setDocEditIndex() {
	if(document.orderbyform.docedit.value=='ALL documents' || document.orderbyform.docedit.value=='ALL layouts' || document.orderbyform.docedit.value=='ALL subtypes' || document.orderbyform.docedit.value=='') {
		document.orderbyform.doceditsel.selectedIndex=0;
	}
	else {
		document.orderbyform.doceditsel.selectedIndex=1;
	}
}


/// layoutmarkersearch.jsp ///
function setLmstring() {
	var submitval;
	var lmarr = document.getElementsByName('layoutmarkers');
	var lmstring;
	var searchinfo;
	var markers = new Array();
	for(i=0;i<lmarr.length;i++) {
		if(lmarr[i].checked==true) {
			//alert(lmarr[i].value);
			markers.push(lmarr[i].value);
		}
	}
	if(markers.length==1) {
			lmstring = 'and name like \''+markers[0]+'\'';
			searchinfo=markers[0];
			submitval=1;
	}
	else if(markers.length>1) {
		if(document.getElementById('connector').value=='AND') {
			lmstring = 'and (name like \''+markers.join('\' and name like \'')+'\')';
			searchinfo = markers.join(' AND ');
			submitval=1;
		}
		else if(document.getElementById('connector').value=='OR') {
			lmstring = 'and (name like \''+markers.join('\' or name like \'')+'\')';
			searchinfo = markers.join(' OR ');
			submitval=1;
		}
	}
	else {
		submitval=0;
	}
	if(submitval==1) {
		document.getElementById('lmstring').value=lmstring;
		document.getElementById('searchinfo').value=searchinfo;
		return true;
	}
	else {
		alert('Choose layout markers and connector');
		return false;
	}
	//alert(lmstring);
}

function setLmAndOr(andor) {
	document.getElementById('connector').value=andor;
}


/// typology.jsp ///
function setSearchMode(modid) {
	if(modid=='searchmod1') {
		document.getElementById('searchmod').value='simple';
		document.getElementById('typesTH').className='collapse';
		document.getElementById('typesTD').className='collapse';
		/*document.getElementById('subjTH').className='collapse';
		document.getElementById('subjTD').className='collapse';*/
		document.getElementById('layoutTH').className='collapse';
		document.getElementById('layoutTD').className='collapse';
	}
	else if(modid=='searchmod2') {
		document.getElementById('searchmod').value='advanced';
		document.getElementById('typesTH').className='';
		document.getElementById('typesTD').className='';
		/*document.getElementById('subjTH').className='';
		document.getElementById('subjTD').className='';*/
		document.getElementById('layoutTH').className='';
		document.getElementById('layoutTD').className='';
	}
}

/*function setSubjstyle(id) {
	if(document.getElementById(id).checked==true) {
		document.getElementById('subjstyle').value=1;
	}
	else {
		document.getElementById('subjstyle').value=0;
	}
}*/

function switchAraLat(araLat) {
	if(araLat=='stringAra') {
		document.getElementById('stringLat').value='';
	}
	else if(araLat=='stringLat') {
		document.getElementById('stringAra').value='';
	}
	else {
		document.getElementById('stringLat').value='';
		document.getElementById('stringAra').value='';
	}
}

function setMaterial(material,index) {
	document.getElementById('material').value=material;
	if(material!='') {
		document.getElementById('matindex').value=index;
	}
	else {
		document.getElementById('matindex').value=0;
	}
}

function setLongname(longname,index) {
	document.getElementById('longname').value=longname;
	if(longname!='') {
		document.getElementById('longnameindex').value=index;
	}
	else {
		document.getElementById('longnameindex').value=0;
	}
}

function setCollection(collection,index) {
	document.getElementById('collection').value=collection;
	if(collection!='') {
		document.getElementById('collindex').value=index;
	}
	else {
		document.getElementById('collindex').value=0;
	}
}

function setKind(kind,index) {
	document.getElementById('kind').value=kind;
	if(kind!='') {
		document.getElementById('kindindex').value=index;
	}
	else {
		document.getElementById('kindindex').value=0;
	}
}

function setWidth(width,index) {
	document.getElementById('width').value=width;
	if(width!='') {
		document.getElementById('widthindex').value=index;
	}
	else {
		document.getElementById('widthindex').value=0;
	}
}

function setHWRel(hwrel,index) {
	// height-width relation
	document.getElementById('hwrel').value=hwrel;
	if(hwrel!='') {
		document.getElementById('hwrelindex').value=index;
	}
	else {
		document.getElementById('hwrelindex').value=0;
	}
}

function toggleFulltextOnly() {
	var checkstate=document.getElementById('fulltextonly').value;
	if(checkstate=='checked') {
		document.getElementById('fulltextonly').value='';
	}
	else if(checkstate=='') {
		document.getElementById('fulltextonly').value='checked';
	}
}

function setIndices() {
/* TYPOLOGY */
	// searchmod:
	if(document.getElementById('searchmod').value=='') {
		searchmod='advanced';
	}
	else {
		searchmod=document.getElementById('searchmod').value;
	}
	if(searchmod=='simple') {
		document.getElementById('searchmod1').click();
	}
	else if(searchmod=='advanced') {
		document.getElementById('searchmod2').click();
	}
	// material:
	matindex=document.getElementById('matindex').value;
	if(matindex!='') {
		document.textlayoutform.matselect.selectedIndex=matindex;
	}
	else {
		document.textlayoutform.matselect.selectedIndex=0;
	}
	// longname:
	longnameindex=document.getElementById('longnameindex').value;
	if(longnameindex!='') {
		document.textlayoutform.longnameselect.selectedIndex=longnameindex;
	}
	else {
		document.textlayoutform.longnameselect.selectedIndex=0;
	}
	// collection:
	collindex=document.getElementById('collindex').value;
	if(collindex!='') {
		document.textlayoutform.collselect.selectedIndex=collindex;
	}
	else {
		document.textlayoutform.collselect.selectedIndex=0;
	}
	// kind:
	kindindex=document.getElementById('kindindex').value;
	if(kindindex!='') {
		document.textlayoutform.kindselect.selectedIndex=kindindex;
	}
	else {
		document.textlayoutform.kindselect.selectedIndex=0;
	}
	// width:
	widthindex=document.getElementById('widthindex').value;
	if(widthindex!='') {
		document.textlayoutform.widthselect.selectedIndex=widthindex;
	}
	else {
		document.textlayoutform.widthselect.selectedIndex=0;
	}
	// hwrel:
	hwrelindex=document.getElementById('hwrelindex').value;
	if(hwrelindex!='') {
		document.textlayoutform.hwrelselect.selectedIndex=hwrelindex;
	}
	else {
		document.textlayoutform.hwrelselect.selectedIndex=0;
	}
	// subjstyle:
	/*subjcheck=document.getElementById('subjstyle').value;
	if(subjcheck==1) {
		document.getElementById('subjcheck').checked=true;
	}*/
}

function setIndicesDocuments() {
/* DOCUMENTS */
	// material:
	/*matindex=document.getElementById('matindex').value;
	if(matindex!='') {
		document.docsearchform.matselect.selectedIndex=matindex;
	}
	else {
		document.docsearchform.matselect.selectedIndex=0;
	}*/
	// longname:
	longnameindex=document.getElementById('longnameindex').value;
	if(longnameindex!='' && longnameindex!='0') {
		document.docsearchform.longnameselect.selectedIndex=longnameindex;
	}
	else {
		//document.docsearchform.longnameselect.selectedIndex=0;
	}
	// collection:
	collindex=document.getElementById('collindex').value;
	if(collindex!='' && collindex!='0') {
		document.docsearchform.collselect.selectedIndex=collindex;
	}
	else {
		//document.docsearchform.collselect.selectedIndex=0;
	}
	// kind:
	kindindex=document.getElementById('kindindex').value;
//alert(kindindex);
	if(kindindex!='' && kindindex!='0') {
//alert('if');
		document.docsearchform.kindselect.selectedIndex=kindindex;
	}
	else {
//alert('else');
		//document.docsearchform.kindselect.selectedIndex=0;
	}
	// fulltextonly:
	checkstate=document.getElementById('fulltextonly').value;
	if(checkstate=='checked') {
		document.getElementById('fulltextcheckbox').checked=true;
	}
}

function setOffset(mode) {
	if(document.getElementById('offset'.value=='')) {
		var currentOffset=0;
	}
	else {
		var currentOffset=parseInt(document.getElementById('offset').value);

	}
	//alert(mode+'; offset: '+currentOffset);
	if(mode=='zero') {
		document.getElementById('offset').value=0;
	}
	else if(mode=='next') {
		document.getElementById('offset').value=currentOffset+20;
	}
	if(mode=='previous') {
		document.getElementById('offset').value=currentOffset-20;
	}
}

function resetIndicesDocuments() {
/* DOCUMENTS */
	// longname:
		document.getElementById('longname').value='';
		document.getElementById('longnameindex').value='';
		document.docsearchform.longnameselect.selectedIndex=0;
	// collection:
		document.getElementById('collection').value='';
		document.getElementById('collindex').value='';
		document.docsearchform.collselect.selectedIndex=0;
	// yearfrom:
		document.getElementById('byear').value='';
	// yearto:
		document.getElementById('eyear').value='';
	// material:
		document.getElementById('material').value='';
		document.docsearchform.material.selectedIndex=0;
	// origplaceid:
		document.getElementById('origplaceid').value='';
		document.docsearchform.origplaceid.selectedIndex=0;
	// kind:
		document.getElementById('kind').value='';
		document.getElementById('kindindex').value='';
		document.docsearchform.kindselect.selectedIndex=0;
	// title:
		document.getElementById('content').value='';
	// language:
		document.getElementById('language').value='';
	// origin:
	// searchanywhere:
		document.getElementById('alldata').value='';
	// fulltextonly:
		document.getElementById('fulltextonly').value='';
		document.getElementById('fulltextcheckbox').checked=false;
	// results:
		document.getElementById('results').innerHTML='';
}

function resetFilters(mode) {
	if(mode=='all') {
		//document.getElementById('name').value='';
		document.getElementById('longname').value='';
		document.getElementById('longnameindex').value='';
		document.textlayoutform.longnameselect.selectedIndex=0;
		document.getElementById('byear').value='';
		document.getElementById('eyear').value='';
		document.getElementById('material').value='';
		document.getElementById('matindex').value='';
		document.textlayoutform.matselect.selectedIndex=0;
		document.getElementById('collection').value='';
		document.getElementById('collindex').value='';
		document.textlayoutform.collselect.selectedIndex=0;
		document.getElementById('invnumber').value='';
		document.getElementById('kind').value='';
		document.getElementById('kindindex').value='';
		document.textlayoutform.kindselect.selectedIndex=0;
		document.getElementById('width').value='';
		document.getElementById('widthindex').value='';
		document.textlayoutform.widthselect.selectedIndex=0;
		document.getElementById('hwrel').value='';
		document.getElementById('hwrelindex').value='';
		document.textlayoutform.hwrelselect.selectedIndex=0;
		switchAraLat('none');
		if(document.getElementById('resultdiv')) {
			document.getElementById('resultdiv').innerHTML='';
		}
	}
	var elements = ['el_trc','el_h','el_tlc','el_rm','el_m','el_lm','el_brc','el_f','el_blc'];
	for(i=0;i<elements.length;i++) {
		document.getElementById(elements[i]).value='';
		document.getElementById(elements[i].replace('el_','')).className='uncertain';
	}
	document.getElementById('layoutregexp').value='';
	document.getElementById('formaltype').value='';
	document.getElementById('formalsubtypegroup').value='';
	document.getElementById('formalsubtype').value='';
	resetTextSel();
	/*document.getElementById('subjcheck').checked=false;
	document.getElementById('subjstyle').value=0;*/
}

function switchElementMode(element) {
	//alert(element);
	if(document.getElementById('el_'+element).value==2 || document.getElementById('el_'+element).value=='') {
		document.getElementById('el_'+element).value=1;
		document.getElementById(element).className='writing';
		//alert('2>1');
	}
	else if(document.getElementById('el_'+element).value==1) {
		document.getElementById('el_'+element).value=0;
		document.getElementById(element).className='';
		//alert('1>0');
	}
	else if(document.getElementById('el_'+element).value==0) {
		document.getElementById('el_'+element).value=2;
		document.getElementById(element).className='uncertain';
		//alert('0>2');
	}
	setLayoutRegexpAndClasses();
}

function setLayoutRegexpAndClasses() {
	var layoutregexp = [];
	var elements = ['el_trc','el_h','el_tlc','el_rm','el_m','el_lm','el_brc','el_f','el_blc'];
	var uncertainty = 0;
	for(i=0;i<elements.length;i++) {
		if(document.getElementById(elements[i]).value==2 || document.getElementById(elements[i]).value=='') {
			layoutregexp.push('('+elements[i].replace('el_','')+'[0-9]+\_)*');
			document.getElementById(elements[i].replace('el_','')).className='uncertain';
			uncertainty++;
		}
		else if(document.getElementById(elements[i]).value==1) {	
			layoutregexp.push(elements[i].replace('el_','')+'[0-9]+\_');
			document.getElementById(elements[i].replace('el_','')).className='writing';
		}
		else if(document.getElementById(elements[i]).value==0) {
			document.getElementById(elements[i].replace('el_','')).className='';
		}
	}
	var layoutregexpstr=layoutregexp.join('');
	if(layoutregexpstr!='') {
		layoutregexpstr="and tlname similar to '"+layoutregexpstr+"[0-9]+'";
	}
	if(uncertainty==9) {
		layoutregexpstr=layoutregexpstr.replace('and ','and (')+" or tlname is null)";
	}
	//alert(layoutregexpstr);
	document.getElementById('layoutregexp').value=layoutregexpstr;
}

function setTextProp(spanid,typeid,stgroupid,subtypeid) {
	resetTextSel();
	//alert(spanid);
	document.getElementById(spanid).className='highlight';
	var formallayers = ['formaltype','formalsubtypegroup','formalsubtype'];
	var formalvalues = [typeid,stgroupid,subtypeid];
	for(i=0;i<formallayers.length;i++) {
		document.getElementById(formallayers[i]).value=formalvalues[i];
		/*if(formalvalues[i]!=0) {
		}*/
	}	
	/*document.getElementById('formaltype').value=typeid;
	document.getElementById('formalsubtypegroup').value=stgroupid;
	document.getElementById('formalsubtype').value=subtypeid;*/
}

function highlightTree() {
	var tfid=document.getElementById('formaltype').value;
	var stgfid=document.getElementById('formalsubtypegroup').value;
	var stfid=document.getElementById('formalsubtype').value;
	if(tfid!='' && tfid!=0) {
		var spanid='tf'+tfid;
	}
	else if(stgfid!='' && stgfid!=0) {
		var spanid='stgf'+stgfid;
		document.getElementById(spanid).parentNode.parentNode.previousSibling.previousSibling.previousSibling.className='icon expanded';
		document.getElementById(spanid).parentNode.parentNode.className='show-list';
	}
	else if(stfid!='' && stfid!=0) {
		var spanid='stf'+stfid;
		document.getElementById(spanid).parentNode.parentNode.previousSibling.previousSibling.previousSibling.className='icon expanded';
		document.getElementById(spanid).parentNode.parentNode.previousSibling.previousSibling.previousSibling.parentNode.parentNode.previousSibling.previousSibling.previousSibling.className='icon expanded';
		document.getElementById(spanid).parentNode.parentNode.className='show-list';
		document.getElementById(spanid).parentNode.parentNode.parentNode.parentNode.className='show-list';
	}
	if(spanid) {
		document.getElementById(spanid).className='highlight';
	}
}

function resetTextSel() {
	var textselarr = document.getElementsByName('texttreesel');
	for(i=0;i<textselarr.length;i++) {
		textselarr[i].className='';
	}
}

function showSubtypeDesc(subtypedesc) {
	//document.getElementById('subtypedesc').innerHTML=subtypedesc;
	if(subtypedesc!='' && subtypedesc!='No subtype description available') {
		document.getElementById('subtypedesc').innerHTML=subtypedesc;
		document.getElementById('subtypedescheading').innerHTML='<span class="five">Subtype description</span>';
	}
	else {
		document.getElementById('subtypedesc').innerHTML=subtypedesc;
		document.getElementById('subtypedescheading').innerHTML='';
	}
}

function showSubtypeDocs(subtype,resultsfor) {
	var stfnames = document.getElementsByName('stfnames');
	document.getElementById('resultsfor').innerHTML=resultsfor;
	for(i=0;i<stfnames.length;i++) {
		var stfname=stfnames[i].id.replace('tr_','');
		if(stfname!=subtype) {
			stfnames[i].className='collapse';
			if(resultsfor=='') {
				document.getElementById('docreshead').className='five collapse';
			}
		}
		else {
			//alert(subtype+'='+stfnames[i].id);
			stfnames[i].className='';
			stfnames[i].firstChild.firstChild.focus();
			document.getElementById('docreshead').className='five';
			//// NEU:
				/*var phr_documents = document.getElementsByName('phr_'+stfname);
				//alert(phr_documents[0]);
				//alert('phr_'+stfname);
				for(j=0;j<phr_documents.length;j++) {
					//alert(phr_documents[j].title);
					var layoutid = phr_documents[j].lang;
					//alert(layoutid);
					var buttons = document.getElementsByName('phr_'+layoutid);
					//var buttons = phr_documents[j].innerHTML.match(/<input[^><]*>/g);
					if(buttons.length>0) {
						for(k=0;k<buttons.length;k++) {
							//alert(buttons[k].value);
							var stfnameRegexp = new RegExp(stfname,"g");
							//alert(stfnameRegexp);
							if(buttons[k].value.match(stfnameRegexp)) {
								//alert(buttons[k].value);
								buttons[k].className="highlight";
							}
						}
					}
				}*/
			////
		}
	}
document.getElementById('mouseclick').value='on'; 
}


/// stgrpdesc.jsp ///
function showStgrpDesc(stgfid) {
	var descid='stgfdesc'+stgfid;
	var stgfdesc=document.getElementById(descid).value;
	document.getElementById('descdiv').innerHTML=stgfdesc;
}

function showStDesc(stfid) {
	var descid='stfdesc'+stfid;
	var stfdesc=document.getElementById(descid).value;
	document.getElementById('descdiv').innerHTML=stfdesc;
}


/// typofinder.jsp ///

function setSupertype(layoutsupertype) {
	document.getElementById('layoutsupertypename').value=layoutsupertype;
	//alert(supertype);
}

function highlightSuperSel(supertype) {
	if(supertype!='') {
//		alert(supertype);
		document.getElementById(supertype).className='highlight';
	}
}

function showLayoutDocLinks(subtype,doclinks) {
	//alert(doclinks);
	document.getElementById('layoutsubtypename').value=subtype;
	document.getElementById('layoutdoclinks').innerHTML=doclinks;
	document.getElementById(subtype).className='highlight';
}

//////////////////////


// TYPO TEXT TREE //

function showOrNot(item) {
	//alert(item.className);
	//alert(":"+item.nextSibling.nextSibling.tagName+":");
	if(item.className.match(/expanded/)) {
		item.className='icon';
		item.nextSibling.nextSibling.className="";
		if(item.nextSibling.nextSibling.nextSibling) {
			item.nextSibling.nextSibling.nextSibling.className="";
		}
		var deep = item.nextSibling.nextSibling;
		var deeparr = deep.getElementsByTagName("DIV");
		for(i=0;i<deeparr.length;i++) {
			deeparr[i].className='icon';
			if(deeparr[i].nextSibling.nextSibling) {
				deeparr[i].nextSibling.nextSibling.className="";
			}
		}
	}
	else if(item.nextSibling.nextSibling) {
		item.className='icon expanded';
		if(item.nextSibling.nextSibling.tagName=='UL') {
			item.nextSibling.nextSibling.className="show-list";
		}
		else if(item.nextSibling.nextSibling.tagName=='TABLE') {
			item.nextSibling.nextSibling.className="show-table";
		}
		/* new1: for layout tree  */	
		else if(item.nextSibling.nextSibling.nextSibling.tagName=='TABLE') {
			item.nextSibling.nextSibling.nextSibling.className="show-table indent-table";
		}
		/* new1 */	
		/* new2: for typology text tree  */	
		else if(item.nextSibling.nextSibling.nextSibling.tagName=='UL') {
			item.nextSibling.nextSibling.nextSibling.className="show-list";
		}
		/* new2 */	
	}
	else {
		item.className='icon empty';
	}
}


// LAYOUT STRUCTURE: Layout Creator //

/*function setActualField(id) {
	document.getElementById('actualfield').value=id;
}*/

function resetLayoutstring() {
	document.getElementById('layoutstring').value='';
	document.getElementById('selectedlayout').value='';
	document.layoutform.foundlayouts.selectedIndex=0;
	document.getElementById('selindex').value='0';
}

function resetLayoutname() {
	document.getElementById('layoutname').value='';
	document.getElementById('tablestr').value='';
	document.layoutform.foundlayouts.selectedIndex=0;
	document.getElementById('selindex').value='0';
}

function setSubmitMode(mode) {
	document.getElementById('submitMode').value=mode;
} 

function chooseLayout(index,name) {
	document.getElementById('selindex').value=index;
	document.getElementById('selectedlayout').value=name.replace(/ \[.*\]/,'');
}

function applyActualField(id) {
	for(i=0;i<document.layoutform["fields[]"].length;i++) {
		if(document.layoutform["fields[]"][i].checked) {
				if(i<document.layoutform["fields[]"].length-1) {
					var num=i+1;
					if(document.getElementById('field'+num).getAttribute('field'+num+'name')=='') {
						alert('Enter field name first!');
					}
					else {
						document.getElementById(id).className='part'+num;
						document.getElementById(id).setAttribute("fieldid",'field'+num);
					}
				}
				else {
					document.getElementById(id).className='';
					document.getElementById(id).setAttribute("fieldid",'');
				}
//			var num=i+1;
//			if(document.getElementById('field'+num).getAttribute('field'+num+'name')=='') {
//				alert('Enter field name first!');
//			}
//			else {
//				if(i<document.layoutform["fields[]"].length-1) {
//					document.getElementById(id).className='part'+num;
//					document.getElementById(id).setAttribute("fieldid",'field'+num);
//				}
//				else {
//					document.getElementById(id).className='';
//					document.getElementById(id).setAttribute("fieldid",'field0');
//				}
//			}
		}
	}
}

function setFieldname(fieldid,fieldname) {
	//alert(fieldid+', '+fieldname);
	document.getElementById(fieldid).setAttribute(fieldid+"name",fieldname);
}

function checkLayoutname(name,layoutstring) {
	var submitval;
	if(name=='' && layoutstring=='') {
		alert('Missing layout name');
		submitval=0;
	}
	/* else if(name!=''&& tablestr=='') {
		alert('Define textfields first!');
		submitval=0;
	} */
	else {
		submitval=1;
	}
	if(submitval==1) {
		return true;
	}
	else {
		return false;
	}
}

function passParams(layoutname) {
	if(layoutname=='') {
	}
	else {
		document.getElementById('layoutname').value=layoutname;
		var tableparams=new Array();
		//var minX=0;
		var maxX=0;
		var maxY=0;
		var minY=0;
		var minYset=0;
		var maxYtmp=0;
		var minYtmp=0;
		for(i=0;i<9;i++) {
			//var num=i+1;
			tableparams[i]=new Array();
			var rowname='r'+i;
			//alert(document.layoutform[rowname+"[]"]);
			var rowArr=document.layoutform[rowname+"[]"];
			//alert(rowArr[i].getAttribute("fieldid"));
			var minXset=0;
			var minXtmp=0;
			for(j=0;j<9;j++) {
				var maxXtmp=0;
			//for(j=8;j>=0;j--) {
				tableparams[i][j]=new Array();
				//alert('rowArr: '+rowArr[j].id);
				//var id=rowArr[j].id;
				var id=document.layoutform[rowname+"[]"][j].id;
				//alert('id: '+id);
				var fieldid=document.layoutform[rowname+"[]"][j].getAttribute("fieldid");
				//alert('fieldid: '+fieldid);
				if(fieldid!='') {
					//minXtmp=j;
					var fieldname=document.getElementById(fieldid).getAttribute(fieldid+'name');
					var classname=document.getElementById(fieldid).parentNode.parentNode.getAttribute("class");
					//alert(document.getElementById(fieldid).parentNode.parentNode.getAttribute("class"));
					//maxXtmp=9-j;
					//maxXtmp=j+1;
					//maxYtmp=i+1;
					maxY=i;
					if(minXset==0) {
						minXtmp=j;
						if(minYset==0) {
							var minX=minXtmp;
							//alert('minX first set: '+minX);
						}
						minXset=1;
						//alert('fieldid: '+fieldid+', minXtmp: '+minXtmp);
					}
					maxXtmp=j;
					//maxX=maxXtmp;
					if(minYset==0) {
						minY=i;
						minYset=1;
					}
				}
				else {
					var fieldname='';
					var classname='';
				}
				//var fieldinfo=fieldname+':'+id;
				//tableparams[i][j]=fieldinfo;
				tableparams[i][j][0]=fieldname;
				tableparams[i][j][1]=id;
				tableparams[i][j][2]=classname;
				if(maxXtmp>maxX) {
					maxX=maxXtmp;
				}
				if(minXset!=0 && minXtmp<minX) {
					//alert('minXtmp<minX, minX: '+minX+', minXtmp: '+minXtmp+', fieldid: @'+fieldid+'@');
					minX=minXtmp;
				}
			}
		}
		if(maxYtmp>maxY) {
			maxY=maxYtmp;
		}
		var tableparamstr=tableparams.join('&');
		document.getElementById('tableparamstr').value='minX: '+minX+'; maxX: '+maxX+'; minY: '+minY+'; maxY: '+maxY+'; '+tableparamstr;
	
		//var xstart=9-maxX;
		var puretablestr='';
		var tablestr='&lt;tr&gt;';
		for(k=minX;k<=maxX;k++) {
			tablestr=tablestr+'&lt;td&gt;&lt;/td&gt;';
		}
		tablestr=tablestr+'&lt;/tr&gt;';
		var prevfname='';
		var currfname='';
		var prevclass='';
		var currclass='';
		var cells=new Array(); // cell contents
		var rowspans=new Array(); // rowspans
		var k=0;
		var index=0;
		var emptycellnum=0;
		for(i=minY;i<=maxY;i++) {
			var fname='';
			var fnameshow='';
			var classinfo='';
			var jstart=minX;
			//var rowspan=1;
			//var rowinfo='';
			tablestr=tablestr+'&lt;tr&gt;';
			var colspan=1;
			//for(j=xstart;j<9;j++) {
			for(j=minX;j<=maxX;j++) {
				var cell='';
				if(tableparams[i][j][0]!='') {
					currfname=tableparams[i][j][0];
					currclassinfo=' class=&quot;'+tableparams[i][j][2]+'&quot;';
				}
				else {
					currfname='';
					currclassinfo='';
				}
				var colinfo='';
				//if(currfname==prevfname && j>xstart) {
				if(currfname==prevfname && j>minX) {
					colspan++;
				}
				if(colspan>1) {
					colinfo=' colspan=&quot;'+colspan+'&quot;';
				}
				else {
					colinfo='';
				}
				//if(currfname!=prevfname && j>xstart) {
				if(currfname!=prevfname && j>minX) {
					jstart=j-minX-1;
					//
					if(prevfname!='') {
						fname=prevfname;
						fnameshow=fname;
					}
					else {
						emptycellnum++;
						fname='x'+emptycellnum;
						fnameshow='';
					}
					//
					classinfo=prevclassinfo;
					cell='&lt;td id=&quot;'+fname+'_'+jstart+'&quot;'+colinfo+classinfo+'&gt;'+fnameshow+'&lt;/td&gt;';
					k=cells.indexOf(cell);
					if(k===-1) {
						cells.push(cell);
						index=cells.length-1;
						rowspans[index]=1;
						tablestr=tablestr+cell;
					}
					else {
						rowspans[k]++;
					}
					//tablestr=tablestr+'&lt;td id=&quot;'+fname+'&quot;'+colinfo+classinfo+'&gt;'+fname+'&lt;/td&gt;';
					colspan=1;
				}
				//if(j==8) {
				if(j==maxX) {
					jstart=j-minX;
					if(currfname!='') {
						fname=currfname;
						fnameshow=fname;
					}
					else {
						emptycellnum++;
						fname='x'+emptycellnum;
						fnameshow='';
					}
					classinfo=currclassinfo;
					if(colspan>1) {
						colinfo=' colspan=&quot;'+colspan+'&quot;';
					}
					else {
						colinfo='';
					}
					cell='&lt;td id=&quot;'+fname+'_'+jstart+'&quot;'+colinfo+classinfo+'&gt;'+fnameshow+'&lt;/td&gt;';
					k=cells.indexOf(cell);
					if(k===-1) {
						cells.push(cell);
						index=cells.length-1;
						rowspans[index]=1;
						tablestr=tablestr+cell;
					}
					else {
						rowspans[k]++;
					}
					//tablestr=tablestr+'&lt;td id=&quot;'+fname+'&quot;'+colinfo+classinfo+'&gt;'+fname+'&lt;/td&gt;';
				}
				prevfname=currfname;
				prevclassinfo=currclassinfo;
			}
			tablestr=tablestr+'&lt;/tr&gt;';
		}
			for(m=0;m<rowspans.length;m++) {
				var from='';
				var to='';
				var cellfrom='';
				var cellto='';
				if(rowspans[m]>1) {
					from=' class';
					to=' rowspan=&quot;'+rowspans[m]+'&quot; class';
					cellfrom=cells[m];
					cellto=cells[m].replace(from,to);
					//alert('from: '+from+'; to: '+to);
					tablestr=tablestr.replace(cellfrom,cellto);
				}
			}
		puretablestr=tablestr.replace(/ id=&quot;(.+?)&quot;/g,'').replace(/ class=&quot;(.+?)&quot;/g,'').replace(/&gt;(.*?)&lt;/g,'&gt;&lt;');	
		//puretablestr=tablestr.replace(/&lt;td(.*?) colspan/g,'&lt;td colspan').replace(/td&gt;(.+?)&lt;\/td/g,'td&gt;&lt\/;td');	
		//}
		var cellstr=cells.join('_');
		var rowstr=rowspans.join('_');
		//alert('cells: '+cellstr+'<br>rowspans: '+rowstr);
	//	document.getElementById('createdlayout').innerHTML=tablestr;
		document.getElementById('tablestr').value=tablestr;
		document.getElementById('puretablestr').value=puretablestr;
		//var outertableOld=document.getElementById('outertable').innerHTML;
		//var outertableNew=outertableOld.replace('XLayouttableX','XaaaaaaX');
		//document.getElementById('newtablestr').value=outertableNew;
	}
}

function getLayoutTableOne() {
	var tablestr='';
	var outertableOld='';
	var outertableNew='';
	if(document.getElementById('tablestr').value!='') {
		tablestr=document.getElementById('tablestr').value;
	}
	else if(document.getElementById('selectedlayout').value!='') {
		tablestr=document.getElementById('layouthtml').value;
	}
	if(tablestr!='') {
		outertableOld=document.getElementById('outertable').innerHTML;
	//	alert(outertable);
		outertableNew=outertableOld.replace('<tr><td>layouttable</td></tr>',tablestr);
		//var outertableNew=outertableOld.replace('Layout name:','XLayout name:X');
		//alert(outertableNew);
		document.getElementById('outertable').innerHTML=outertableNew;
	}
}

/***********************/
/* Layout Field Search */
/***********************/

function getLayoutFields() {
	var outertableOld='';
	var outertableNew='';
	outertableOld=document.getElementById('outertable').innerHTML;
	outertableNew=document.getElementById('layouthtml').value.replace(/(tf[0-9]+)_[0-9]+/g,'$1');
	document.getElementById('outertable').innerHTML=outertableNew;
}

function setSearchString(string,tfid) {
	document.getElementById('searchstring').value=string;
	document.getElementById('inputfield').value=tfid;
	var inputarr=document.getElementsByName("inputfields[]");
	var inputnumber=inputarr.length;
	//alert(':'+inputnumber+':');
	for(i=0;i<inputnumber;i++) {
		if(document.fieldsearchform["inputfields[]"][i].value!=string) {
			document.fieldsearchform["inputfields[]"][i].value='';
		}
	}
}

function showSearchString() {
	if(document.getElementById('inputfield').value!='') {
		var tfid=document.getElementById('inputfield').value;
		var searchstring=document.getElementById('searchstring').value;
		//alert('tfid:'+tfid+', searchstring:'+searchstring)
		document.getElementById(tfid).children[0].value=searchstring;
	}
}

/*******************/


/*******************/
/* Metadata Search */
/*******************/
function setKind(kind,index) {
	document.getElementById('kind').value=kind;
	if(kind!='') {
		document.getElementById('kindindex').value=index;
	}
	else {
		document.getElementById('kindindex').value=0;
	}
}

function setOrigin(origin,index,level) {
	document.getElementById('origin').value=origin.replace(/^[ -]*/g,'');
	if(origin!='') {
		document.getElementById('originindex').value=index;
		document.getElementById('originlevel').value=level;
	}
	else {
		document.getElementById('originindex').value=0;
	}
}

function setDateFrom(datefrom) {
	document.getElementById('datefrom').value=datefrom;
}

function setDateTo(dateto) {
	document.getElementById('dateto').value=dateto;
}

function setEditor(editor,index) {
	document.getElementById('editor').value=editor;
	if(editor!='') {
		document.getElementById('editorindex').value=index;
	}
	else {
		document.getElementById('editorindex').value=0;
	}
}

function setSelectedKindOriginEditor(kindindex,originindex,editorindex) {
	document.metasearchform.kindselect.selectedIndex=kindindex;
	document.metasearchform.originselect.selectedIndex=originindex;
	document.metasearchform.editorselect.selectedIndex=editorindex;
}

/*******************/


function getAllLayoutTables() {
	var layouthtmls=document.getElementsByName('layouthtmls');
	var from='';
	var to='';
	for(i=0;i<layouthtmls.length;i++) {
	var innertableId='tab_'+layouthtmls[i].id.replace('TAB','');
	var innertableNew=layouthtmls[i].value;
	document.getElementById(innertableId).innerHTML=innertableNew;
	}
}


/*******************/

function getLayoutTableDisplayOnly() {
	getLayoutTable();
}

function cleanTextTable() {
	if(document.getElementById('etitext').innerHTML=='') {
		document.getElementById('etitext').setAttribute('style','');
	}
}

function getLayoutTable() {
	var tablestr_r='';
	var tablestr_v='';
	var outertableOld='';
	var outertableNew='';
	//alert('getLayoutTable');
/*	if(document.getElementById('tablestr') && document.getElementById('tablestr').value!='') {
		tablestr=document.getElementById('tablestr').value;
	}
	else*/
/* RECTO */
	if(document.getElementById('selectedlayout_r').value!='') {
		tablestr_r=document.getElementById('layouthtml_r').value;
		//alert(tablestr_r);
	}
	if(tablestr_r!='') {
		outertableOld=document.getElementById('outertable').innerHTML;
	//	alert(outertable);
		outertableNew=outertableOld.replace('<tr><td>layouttableR</td></tr>',tablestr_r);
		//outertableNew=outertableOld.replace('<tr><td style="color:#f5eed1">layouttableR</td></tr>',tablestr_r);
		//alert(outertableNew);
		document.getElementById('outertable').innerHTML=outertableNew;
	}
	else {
		document.getElementById('re1').className='collapse';
		document.getElementById('re2').className='collapse';
		document.getElementById('re3').className='collapse';
		document.getElementById('re4').className='collapse';
	}
	if(document.getElementById('layoutsvg_r').getAttribute('src')=='svgimg/.svg') {
		//document.getElementById('layoutsvg_r').src='svgimg/anyreplace.svg';
		document.getElementById('layoutsvg_r').src='';
		document.getElementById('layoutsvg_r').width=0;
		document.getElementById('layoutsvg_r').height=0;
	}
/* VERSO */
	if(document.getElementById('selectedlayout_v').value!='') {
		tablestr_v=document.getElementById('layouthtml_v').value;
		//alert(tablestr_v);
	}
	if(tablestr_v!='') {
		outertableOld=document.getElementById('outertable').innerHTML;
	//	alert(outertable);
		outertableNew=outertableOld.replace('<tr><td>layouttableV</td></tr>',tablestr_v);
		//outertableNew=outertableOld.replace('<tr><td style="color:#f5eed1">layouttableV</td></tr>',tablestr_v);
		//alert(outertableNew);
		document.getElementById('outertable').innerHTML=outertableNew;
	}
	else {
		document.getElementById('ve1').className='collapse';
		document.getElementById('ve2').className='collapse';
		document.getElementById('ve3').className='collapse';
	}
	if(document.getElementById('layoutsvg_v').getAttribute('src')=='svgimg/.svg') {
		//document.getElementById('layoutsvg_v').src='svgimg/anyreplace.svg';
		document.getElementById('layoutsvg_v').src='';
		document.getElementById('layoutsvg_v').width=0;
		document.getElementById('layoutsvg_v').height=0;
	}
}

function setSelIndex() {
	if(document.getElementById('submitMode').value=='rename' || document.getElementById('submitMode').value=='delete') {
		chooseLayout('0','');
	}
//	if(document.getElementById('selindex').value!='' && document.getElementById('submitMode').value!='rename') {
		document.layoutform.foundlayouts.selectedIndex=document.getElementById('selindex').value;
//	}
}

// LAYOUT STRUCTURE: Layout Connector //


function setLayouttype(occasion,givenindex,rv) {
	var setindex_r=0;
	var setindex_v=0;
	var setid_r='';
	var setid_v='';
	var otherlayoutid=0;
	//alert('given index: '+givenindex);
	var layoutsel_r=document.docform["layouttypesel_r"];
	var layoutsel_v=document.docform["layouttypesel_v"];
	if(occasion=='changeR' || occasion=='changeV') {
		//alert('change');
		document.getElementById('importcase').value='normal';
		if(rv=='R') {
			otherlayoutid=document.getElementById('layouttypeid_v').value;
			document.getElementById('keepeti').value=otherlayoutid;
			document.getElementById('layoutcase').value='changeR';
			for(i=0;i<layoutsel_r.length;i++) {
				if(layoutsel_r.options[i].selected==true) {
					setindex_r=i;
					setid_r=layoutsel_r.options[i].id;
				}
			}
		}
		else if(rv=='V') {
			otherlayoutid=document.getElementById('layouttypeid_r').value;
			document.getElementById('keepeti').value=otherlayoutid;
			document.getElementById('layoutcase').value='changeV';
			for(i=0;i<layoutsel_v.length;i++) {
				if(layoutsel_v.options[i].selected==true) {
					setindex_v=i;
					setid_v=layoutsel_v.options[i].id;
				}
			}
		}
	//alert('otherlayoutid: '+otherlayoutid);
	}
	else if(occasion=='load') {
		document.getElementById('layoutcase').value='load';
		//alert('load');
		var setindexarr=givenindex.split('x');
		setindex_r=setindexarr[0];
		setindex_v=setindexarr[1];
		setid_r=layoutsel_r.options[setindex_r].id;		
		setid_v=layoutsel_v.options[setindex_v].id;		
	}
	document.getElementById('layouttypeid_r').value=setid_r.replace('layoutRopt','');
	document.getElementById('layouttypeid_v').value=setid_v.replace('layoutVopt','');
	document.getElementById('layouttypeindex_r').value=setindex_r;
	document.getElementById('layouttypeindex_v').value=setindex_v;
//	alert('index: '+setindex+', id: '+setid);
	if(occasion=='changeR' || setindex_r==0) {
		document.getElementById('layoutsubtypeid_r').value=0;
		document.getElementById('layoutsubtypename_r').value='';
	}
	if(occasion=='changeV' || setindex_v==0) {
		document.getElementById('layoutsubtypeid_v').value=0;
		document.getElementById('layoutsubtypename_v').value='';
	}
}

function setLayoutsubtype(occasion,givenid,rv) {
//	var setindex_r=0;
//	var setindex_v=0;
	var setid_r='';
	var setid_v='';
	var setvalue_r='';
	var setvalue_v='';
	//alert('given id: '+givenid);
	var layoutsel_r=document.docform["layouttypesel_r"];
	var layoutsel_v=document.docform["layouttypesel_v"];
	if(occasion=='changeR' || occasion=='changeV') {
		//alert('change');
		document.getElementById('importcase').value='normal';
		if(rv=='R') {
			document.getElementById('layoutcase').value='changeR';
			setid_r=givenid;
			setvalue_r=document.getElementById(setid_r).value;
			//document.getElementById('drawbtn_r').value=setvalue_r;
		}
		else if(rv=='V') {
			document.getElementById('layoutcase').value='changeV';
			setid_v=givenid;
			setvalue_v=document.getElementById(setid_v).value;
		}
	}
	else if(occasion=='load') {
		document.getElementById('layoutcase').value='load';
		//alert('load');
		var setidarr=givenid.split('x');
		setid_r=setidarr[0];
		setid_v=setidarr[1];
		if(setid_r!=0) {
			if(document.getElementById('sublayoutRopt'+setid_r)) {	
				setvalue_r=document.getElementById('sublayoutRopt'+setid_r).value;
			}
		}
		else {
			setvalue_r='';
		}
		if(setid_v!=0) {
			if(document.getElementById('sublayoutVopt'+setid_v)) {	
				setvalue_v=document.getElementById('sublayoutVopt'+setid_v).value;
			}
		}
		else {
			setvalue_v='';
		}
		//alert('setvalue_r: '+setvalue_r+' ::: setvalue_v: '+setvalue_v);
	}
		document.getElementById('layoutsubtypeid_r').value=setid_r.replace('sublayoutRopt','');
		document.getElementById('layoutsubtypename_r').value=setvalue_r;
		document.getElementById('layoutsubtypeid_v').value=setid_v.replace('sublayoutVopt','');
		document.getElementById('layoutsubtypename_v').value=setvalue_v;
}

function setLayoutsubSelAndImage() {
	/* RECTO */
	var layoutsubtypename_r = document.getElementById('layoutsubtypename_r').value;
	if(layoutsubtypename_r!='') {
		document.getElementById('drawbtn_r').value=layoutsubtypename_r;
		document.getElementById('layoutsvg_r').src='svgimg/'+layoutsubtypename_r+'.svg';
		document.getElementById('layoutsvg_r').setAttribute('width','200');
		document.getElementById('layoutsvg_r').setAttribute('height','282');
	}
	/* VERSO */
	var layoutsubtypename_v = document.getElementById('layoutsubtypename_v').value;
	if(layoutsubtypename_v!='') {
		document.getElementById('drawbtn_v').value=layoutsubtypename_v;
		document.getElementById('layoutsvg_v').src='svgimg/'+layoutsubtypename_v+'.svg';
		document.getElementById('layoutsvg_v').setAttribute('width','200');
		document.getElementById('layoutsvg_v').setAttribute('height','282');
	}
}

function setLayoutSel() {
	/* RECTO */
	var layoutindex_r = document.getElementById('layouttypeindex_r').value;
	//var layoutsubindex_r = document.getElementById('layoutsubtypeindex_r').value;
	document.docform.layouttypesel_r.selectedIndex=layoutindex_r;
	//document.docform.layoutsubtypesel.selectedIndex_r=layoutsubindex_r;
	/* VERSO */
	var layoutindex_v = document.getElementById('layouttypeindex_v').value;
	//var layoutsubindex_v = document.getElementById('layoutsubtypeindex_v').value;
	document.docform.layouttypesel_v.selectedIndex=layoutindex_v;
	//document.docform.layoutsubtypesel.selectedIndex_v=layoutsubindex_v;
}

function setRectoVerso(tableid) {
	var rv=tableid.replace('layouttable_','');
	document.getElementById('rectoverso').value=rv;
	//alert('adding '+rv.replace('r','RECTO').replace('v','VERSO')+' field...');
} 

function setLayoutfield(id) {
	document.getElementById('layoutfield').value=id;
}

function applyLayoutfieldAndMarkers(tokno,edid,lineid,textpos) {
	if(document.getElementById('rectoverso').value=='r') {
		var layouttypeid = document.getElementById('layouttypeid_r').value;
	}
	else if(document.getElementById('rectoverso').value=='v') {
		var layouttypeid = document.getElementById('layouttypeid_v').value;
	}
	else {
		var layouttypeid = 'NULL';
	}
	var layoutfieldname = document.getElementById('layoutfield').value;
	var markerid = document.getElementById('layoutmarkerid').value.replace('mark','');
	var marker = document.getElementById('layoutmarker').value;
	var highlight='';
	if(marker!='') {
		highlight=' marker';
	}
	//document.getElementById(tokno).className=layoutfieldname.replace('tf','part');
	document.getElementById(tokno).className=layoutfieldname.replace('tf','part')+highlight;
/*	document.getElementById(tokno).setAttribute("phraseid",phraseid);
	document.getElementById(tokno).setAttribute("title",marker);
*/
	document.getElementById(tokno).setAttribute("layouttypeid",layouttypeid);
	document.getElementById(tokno).setAttribute("fieldname",layoutfieldname);
	document.getElementById(tokno).setAttribute("layoutmarkerid",markerid);
}

// eti //

function setEtiLayout(toknum) {
	//alert('setEtiLayout');
	document.getElementById('eticase').value='save';
	var etidataarr = new Array();
	var etidatastr;
	for(i=1;i<=toknum;i++) {
		var edid=document.getElementById('tok'+i).getAttribute("name");
		var editor=document.getElementById('tok'+i).getAttribute("editor");
		var layouttypeid=document.getElementById('tok'+i).getAttribute("layouttypeid");
		if(layouttypeid==0) {
			layouttypeid='NULL';
		}
		var layoutfieldname=document.getElementById('tok'+i).getAttribute("fieldname");
		if(layoutfieldname==0) {
			layoutfieldname='';
		}
		var layoutmarkerid=document.getElementById('tok'+i).getAttribute("layoutmarkerid");
		/*if(layoutmarkerid==0) {
			layoutmarkerid='NULL';
		} */
		etidataarr.push('update typo_etiunitsarab set layouttypeid='+layouttypeid+',layoutfieldname=\''+layoutfieldname+'\',layoutmarkerid=\''+layoutmarkerid+'\',changedon=now() where apd_edunitid='+edid+' and editor like \''+editor+'\';');
		//etidataarr.push(edid+':'+layoutfieldname+':'+layoutmarkerid);
		//alert('edid: '+edid+', layoutfieldname: '+layoutfieldname+', layoutmarkerid: '+layoutmarkerid);
	}
	etidatastr=etidataarr.join('');
	document.getElementById('etidata').value=etidatastr;
	//alert(etidatastr);
}

function removeEtiLayout(toknum) {
	document.getElementById('eticase').value='save';
	var keepeti=document.getElementById('keepeti').value;
	var etidataarr = new Array();
	var etidatastr;
	for(i=1;i<=toknum;i++) {
		var edid=document.getElementById('tok'+i).getAttribute("name");
		var editor=document.getElementById('tok'+i).getAttribute("editor");
		var layouttypeid='NULL';
		var layoutfieldname='';
		var layoutmarkerid='';
		if(keepeti==0) {
			etidataarr.push('update typo_etiunitsarab set layouttypeid='+layouttypeid+',layoutfieldname=\''+layoutfieldname+'\',layoutmarkerid=\''+layoutmarkerid+'\' where apd_edunitid='+edid+' and editor like \''+editor+'\';');
		//etidataarr.push(edid+':'+layoutfieldname+':'+layoutmarkerid);
		///lert('edid: '+edid+', layoutfieldname: '+layoutfieldname+', layoutmarkerid: '+layoutmarkerid);
		}
		else {
			etidataarr.push('update typo_etiunitsarab set layouttypeid='+layouttypeid+',layoutfieldname=\''+layoutfieldname+'\',layoutmarkerid=\''+layoutmarkerid+'\' where apd_edunitid='+edid+' and editor like \''+editor+'\' and layouttypeid!='+keepeti+';');
		}
	}
	etidatastr=etidataarr.join('');
	//alert(etidatastr);
	document.getElementById('etidata').value=etidatastr;
}

//function setMarker(marker,markerid) {
function setMarkers() {
	var markerarr = new Array();
	var markeridarr = new Array();
	for(i=0;i<document.docform["markers[]"].length;i++) {
		if(document.docform["markers[]"][i].selected==true) {
			markerarr.push(document.docform["markers[]"][i].value);
			markeridarr.push(document.docform["markers[]"][i].id.replace('mark',''));
		}
	}
	var markerstr = markerarr.join(',');
	var markerids = markeridarr.join(',');
	//alert(markerstr);
	//alert(markerids);
	document.getElementById('layoutmarker').value=markerstr;	
	document.getElementById('layoutmarkerid').value=markerids;	
//	resetMarkers();
//	document.getElementsByName('frphrsel[]').selectedIndex=1;
}

function resetMarkers() {
	//document.docform.markersel.selectedIndex=0;
	document.getElementById('layoutmarker').value='';
	document.getElementById('layoutmarkerid').value='';
}



// TEXT STRUCTURE //

function setDocName(name) {
	document.getElementById('').value='';
}

function setFormtype(occasion,givenindex) {
	var formsel=document.docform["formtypesel"];
	if(occasion=='change') {
//		alert('change');
		document.getElementById('formcase').value='change';
		document.getElementById('importcase').value='normal';
		for(i=0;i<formsel.length;i++) {
			if(formsel.options[i].selected==true) {
				setindex=i;
				setid=formsel.options[i].id;
			}
		}
	}
	else if(occasion=='load') {
		document.getElementById('formcase').value='load';
//		alert('load');
		setindex=givenindex;
		setid=formsel.options[givenindex].id;		
	}
	document.getElementById('formtypeid').value=setid;
	document.getElementById('formtypeindex').value=setindex;
//	alert('index: '+setindex+', id: '+setid);
}

/*function setFormtype(id,index) {
	document.getElementById('formtypeid').value=id;
	document.getElementById('formtypeindex').value=index;
}*/

function setFormsubtype(occasion,givenindex) {
	var formsubsel=document.docform["formsubtypesel"];
	if(occasion=='change') {
		document.getElementById('formsubcase').value='change';
		document.getElementById('importcase').value='normal';
//		alert('change');
		for(i=0;i<formsubsel.length;i++) {
			if(formsubsel.options[i].selected==true) {
				setindex=i;
				setid=formsubsel.options[i].id;
			}
		}
	}
	else if(occasion=='load') {
		document.getElementById('formsubcase').value='load';
//		alert('load');
		setindex=givenindex;
		setid=formsubsel.options[givenindex].id;		
	}
	document.getElementById('formsubtypeid').value=setid;
	document.getElementById('formsubtypeindex').value=setindex;
//	alert('index: '+setindex+', id: '+setid);
}

/*function setFormsubtype(id,index) {
	document.getElementById('formsubtypeid').value=id;
	document.getElementById('formsubtypeindex').value=index;
}*/

function setFormFormsubSel() {
	var formindex = document.getElementById('formtypeindex').value;
	var formsubindex = document.getElementById('formsubtypeindex').value;
	document.docform.formtypesel.selectedIndex=formindex;
	document.docform.formsubtypesel.selectedIndex=formsubindex;
}

// textselection //
function beginSelection(id) {
	document.getElementById('currentselfrom').value=id;
	if(document.docform["textparts[]"]) {
		for(i=0;i<document.docform["textparts[]"].length;i++) {
			if(document.docform["textparts[]"][i].checked) {
				document.docform["textparts[]"][i].checked=false;
			}
		}
//	document.getElementById('textpart').value='';
		document.getElementById('freephrase').value='';
		document.getElementById('freephraseid').value='';
		document.getElementById('keyphraseid').value='';
	}
	if(document.getElementById('markersel')) {
		document.getElementById('layoutmarkerid').value='';
		document.getElementById('layoutmarker').value='';
	}
}

function endSelection(id) {
	document.getElementById('currentselto').value=id;
}

function applySelection() {
	document.getElementById('currenteti').value='';
	var selfrom = Number(document.getElementById('currentselfrom').value.replace('tok',''));
	var selto = Number(document.getElementById('currentselto').value.replace('tok',''));
	if(selfrom!='' && selto!='') {
		if(selfrom<selto || selfrom==selto) {
			for(i=selfrom;i<=selto;i++) {
				document.getElementById('tok'+i).click();
			}
		}
		else {
			for(i=selto;i<=selfrom;i++) {
				document.getElementById('tok'+i).click();
			}
		}
	}
}

// eti //

function setEti(toknum) {
	document.getElementById('eticase').value='save';
	var etidataarr = new Array();
	var etidatastr;
	for(i=1;i<=toknum;i++) {
		var muid=document.getElementById('tok'+i).getAttribute("name");
		var editor=document.getElementById('tok'+i).getAttribute("editor");
		var textpartid=document.getElementById('tok'+i).getAttribute("textpartid");
		if(textpartid==0) {
			textpartid='NULL';
		}
		var phraseid=document.getElementById('tok'+i).getAttribute("phraseid");
		if(phraseid==0) {
			phraseid='NULL';
		}
		etidataarr.push('update typo_etiunitstranslit set textpartid='+textpartid+',phraseid='+phraseid+',changedon=now() where apd_morphunitid='+muid+' and editor like \''+editor+'\';');
		//etidataarr.push(muid+':'+textpartid+':'+phraseid);
		//alert('muid: '+muid+', textpartid: '+textpartid+', phraseid: '+phraseid);
	}
	etidatastr=etidataarr.join('');
	document.getElementById('etidata').value=etidatastr;
	//alert(etidatastr);
}

function updateTokensTranslit() {
	alert('Tokens are being updated...');
}

function resetEti() {
	document.getElementById('etidata').value='';
	document.getElementById('eticase').value='show';
}

function removeEti(toknum) {
	document.getElementById('eticase').value='save';
	var etidataarr = new Array();
	var etidatastr;
	for(i=1;i<=toknum;i++) {
		var muid=document.getElementById('tok'+i).getAttribute("name");
		var editor=document.getElementById('tok'+i).getAttribute("editor");
		var textpartid='NULL';
		var phraseid='NULL';
		etidataarr.push('update typo_etiunitstranslit set textpartid='+textpartid+',phraseid='+phraseid+' where apd_morphunitid='+muid+' and editor like \''+editor+'\';');
		//etidataarr.push(muid+':'+textpartid+':'+phraseid);
		//alert('muid: '+muid+', textpartid: '+textpartid+', phraseid: '+phraseid);
	}
	etidatastr=etidataarr.join('');
	document.getElementById('etidata').value=etidatastr;
}

// textmarkersearch //

function chooseMarker(name) {
	document.getElementById('markerName').value=name;
//	alert('hallo');
//	return checkMarkername(name);
}

function checkMarkerstring(str) {
	var submitval;
	if(str.length<2) {
		alert('Specify search string!');
		submitval=0
	}
	else {
		submitval=1;
	}
	if(submitval==1) {
		//return true;
		document.markerselect.submit();
	}
	else {
		//return false;
	}
}

function checkMarkername(name) {
	chooseMarker(name);
	var submitval;
	if(name=='') {
		alert('Choose marker first!');
		submitval=0
	}
	else {
		submitval=1;
	}
	if(submitval==1) {
		//return true;
		document.markerselect.submit();
	}
	else {
		//return false;
	}
}

// textparts //

function chooseDoc(name,editor) {
	//document.getElementById('docName').value=name;
	document.getElementById('docName').value=name.replace(' ('+editor+')','');
}

function chooseDocNameIdEd(name,papidEd) {
	document.getElementById('docName').value=name.replace(/ \(ed: .*$/,'');
	var splitArr = papidEd.split(":");
	document.getElementById('docPapid').value=splitArr[0];
	document.getElementById('docEd').value=splitArr[1];
}

function checkDocstring(str) {
	var submitval;
	if(str.length<5) {
		alert('Specify search string!');
		submitval=0
	}
	else {
		submitval=1;
	}
	if(submitval==1) {
		return true;
	}
	else {
		return false;
	}
}

function checkDocName(name) {
	var submitval;
	if(name=='') {
		alert('Choose document first!');
		submitval=0
	}
	else {
		submitval=1;
	}
	if(submitval==1) {
		return true;
	}
	else {
		return false;
	}
}

function checkDocNameAndType(name) {
	var submitval;
	if(name=='') {
		alert('Choose document first!');
		submitval=0
	}
	else {
		submitval=confirm('Changing type or subtype will REMOVE all existing mark-up for this document. CHANGE now?');
		//submitval=1;
	}
	if(submitval==1) {
		return true;
	}
	else {
		return false;
	}
}

function checkDocNameAndLayout(name) {
	var submitval;
	if(name=='') {
		alert('Choose document first!');
		submitval=0
	}
	else {
		submitval=confirm('Changing type will REMOVE all existing mark-up for this part of the document (R or V). CHANGE now?');
		//submitval=1;
	}
	if(submitval==1) {
		return true;
	}
	else {
		return false;
	}
}

function setTextpart(textpart) {
	for(i=0;i<document.docform["textparts[]"].length;i++) {
		if(document.docform["textparts[]"][i].checked) {
			document.getElementById('textpart').value=document.docform["textparts[]"][i].id;
		}
	}
	for(i=0;i<document.docform["keyphrsel[]"].length;i++) {
		document.docform["keyphrsel[]"][i].selectedIndex=0;
		if(document.docform["textparts[]"][i].checked) {
			document.docform["keyphrsel[]"][i].disabled=false;
			document.getElementById('keyphrase').value='';
			document.getElementById('keyphraseid').value='';
		}
		else {
			document.docform["keyphrsel[]"][i].disabled=true;
	//		document.docform["keyphrsel[]"][i].selectedIndex=0;
		}
	}
	document.docform.frphrsel.selectedIndex=0;
	document.getElementById('freephrase').value='';	
	document.getElementById('freephraseid').value='';	
//	document.getElementById('textpartstarted').value=0;
}

function applyTextpart(tokno,muid,lineid,textpos) {
	var textpart = document.getElementById('textpart').value;
	document.getElementById(tokno).className=textpart;
}

function applyTextpartAndPhrases(tokno,muid,lineid,textpos) {
	var textpart = document.getElementById('textpart').value;
	var textpartid = document.getElementById(textpart).getAttribute("textpartid");
	var keyphraseid = document.getElementById('keyphraseid').value;
	var keyphrasename = document.getElementById('keyphrase').value;
	var freephraseid = document.getElementById('freephraseid').value;
	var freephrasename = document.getElementById('freephrase').value;
	var phrasekind;
	var phraseid;
	var phrasename;
	if(freephraseid!='') {
		phrasekind=' freephr';
		phraseid=freephraseid.replace('phr','');
		phrasename=freephrasename;
	}
	else if(keyphraseid!='') {
		phrasekind=' keyphr';
		phraseid=keyphraseid.replace('phr','');
		phrasename=keyphrasename;
	}
	else {
		phrasekind='';
		phraseid='';
		phrasename='';
	}
	document.getElementById(tokno).className=textpart+phrasekind;
	document.getElementById(tokno).setAttribute("phraseid",phraseid);
	document.getElementById(tokno).setAttribute("title",phrasename);
	document.getElementById(tokno).setAttribute("textpartid",textpartid);
}

// phrases //

function applyPhrases(id,name,lineid,textpos) {
	if(document.getElementById('freephrase').value!='') {
		applyFreePhrase(id);
	}
	if(document.getElementById('keyphrase').value!='') {
		applyKeyPhrase(id);
	}
}

function setFreePhrase(fphrase,phrid) {
	document.getElementById('freephrase').value=fphrase;	
	document.getElementById('freephraseid').value=phrid;	
//	document.getElementById('textpart').value='';
//	document.docform.keyphrsel.selectedIndex=0;
	for(i=0;i<document.docform["keyphrsel[]"].length;i++) {
		document.docform["textparts[]"][i].checked=false;
		document.docform["keyphrsel[]"][i].disabled=true;
		document.docform["keyphrsel[]"][i].selectedIndex=0;
	}
	document.getElementById('keyphrase').value='';	
	document.getElementById('keyphraseid').value='';	
}

function setKeyPhrase(kphrase,phrid) {
	document.getElementById('keyphrase').value=kphrase;	
	document.getElementById('keyphraseid').value=phrid;	
//	document.getElementsByName('frphrsel[]').selectedIndex=1;
}

function applyFreePhrase(id) {
	alert(document.getElementById(id).className);
//	document.getElementById(id).className += ' freephr';
	//document.getElementById('freephrase').value='';	
}

function applyKeyPhrase(id) {
	alert(document.getElementById(id).className);
//	document.getElementById(id).className += ' keyphr';
	//document.getElementById('keyphrase').value='';	
}

/////////////

// TYPOCATEGORIES //

//var catTables = ["typo_typesfunctional","typo_typesformal","typo_textparts","typo_phrases","typo_phrases","typo_typeslayout","typo_layoutblocks"];
var catTables = ["typo_typesformal","typo_subtypesformal","typo_textblocks","typo_textparts","typo_phrases","typo_phrases","typo_subtypegroupsformal"];

function selectCategory(cat) {
	var catnum = Number(cat.replace('cat',''));
	if(catnum>100) {
		var a=100;
	}
	else {
		var a=0;
	}
	if(catnum!=99) {
		setOpTable(catnum-a);
	}
	else {
		setOpTable(2);
	}
	if(catnum==a+5) {
		document.getElementById('opphrasekind').value='keyphr';
	}
	else if(catnum==a+6) {
		document.getElementById('opphrasekind').value='freephr';
	}
	else {
		document.getElementById('opphrasekind').value='';
	}
	setOpId('');
	setOpName('');
	setOpInput('','');
//	setOp('');
	disableUnselected(catnum);
}

function disableUnselected(catnum) {
	if(catnum>100) {
		var catlength = document.catform["categories2[]"].length;
		var a=100;
		var b='2';
	}
	else {
		var catlength = document.catform["categories1[]"].length;
		var a=0;
		var b='1';
	}
	for(i=a+1;i<=a+catlength;i++) {
//		alert('catnum: '+catnum);
//		alert('i: '+i);
		if(i==catnum) {
			document.getElementById('sel'+i).disabled=false;
			if(i!=a+1) {
				document.getElementById('inputtext'+i).disabled=false;
				if(catnum>100) {
					document.getElementById('update'+i).disabled=false;
				}
				else {
					if(i!=a+7) {
						document.getElementById('rem'+i).disabled=false;
					}
					document.getElementById('add'+i).disabled=false;
				}
			}
			if(i==a+7) {
//				alert('catnum=7');
				document.getElementById('sel7belongstoform'+b).disabled=false;
			}
			if(i==a+2) {
//				alert('catnum=2');
				document.getElementById('selbelongstoform'+b).disabled=false;
			}
			if(i==a+3) {
//				alert('catnum=3');
				document.getElementById('selbelongstoformsub'+b).disabled=false;
				document.getElementById('sel3occurrence'+b).disabled=false;
			}
			if(i==a+4) {
//				alert('catnum=4');
				document.getElementById('selbelongstotextblock'+b).disabled=false;
				document.getElementById('sel4occurrence'+b).disabled=false;
			}
			if(i==a+5) {
//				alert('catnum=5');
				document.getElementById('selbelongstotextpart'+b).disabled=false;
			}
		}
		else if(i==8 && catnum==99) {
//				alert('catnum=99');
				document.getElementById('subtypesel').disabled=false;
				document.getElementById('subtypegroupsel').disabled=false;
				document.getElementById('connect99').disabled=false;
		}
		else if(i!=8) {
			document.getElementById('sel'+i).options.selectedIndex=0;
			document.getElementById('sel'+i).disabled=true;
			document.getElementById('inputtext'+i).disabled=true;
			document.getElementById('inputtext'+i).value='';
			if(catnum>100) {
				document.getElementById('update'+i).disabled=true;
			}
			else {
				document.getElementById('rem'+i).disabled=true;
				document.getElementById('add'+i).disabled=true;
			}
			if(i==a+7) {
//				alert('catnum!=2');
				document.getElementById('sel7belongstoform'+b).options.selectedIndex=0;
				document.getElementById('sel7belongstoform'+b).disabled=true;
			}
			if(i==a+2) {
//				alert('catnum!=2');
				document.getElementById('selbelongstoform'+b).options.selectedIndex=0;
				document.getElementById('selbelongstoform'+b).disabled=true;
			}
			if(i==a+3) {
//				alert('catnum!=3');
				document.getElementById('selbelongstoformsub'+b).options.selectedIndex=0;
				document.getElementById('selbelongstoformsub'+b).disabled=true;
				document.getElementById('sel3occurrence'+b).options.selectedIndex=0;
				document.getElementById('sel3occurrence'+b).disabled=true;
			}
			if(i==a+4) {
//				alert('catnum!=4');
				document.getElementById('selbelongstotextblock'+b).options.selectedIndex=0;
				document.getElementById('selbelongstotextblock'+b).disabled=true;
				document.getElementById('sel4occurrence'+b).options.selectedIndex=0;
				document.getElementById('sel4occurrence'+b).disabled=true;
			}
			if(i==a+5) {
//				alert('catnum!=5');
				document.getElementById('selbelongstotextpart'+b).options.selectedIndex=0;
				document.getElementById('selbelongstotextpart'+b).disabled=true;
			}
		}
		else if(i==8) {
			document.getElementById('subtypesel').options.selectedIndex=0;
			document.getElementById('subtypesel').disabled=true;
			document.getElementById('subtypegroupsel').options.selectedIndex=0;
			document.getElementById('subtypegroupsel').disabled=true;
			document.getElementById('connect99').disabled=true;
		}
	}
}

function setOp(operation) {
	document.getElementById('op').value=operation;
}

function setOpId(id,action) {
	document.getElementById('opid').value=id;
	setOp(action);
}

function setOpName(name) {
	document.getElementById('opname').value=name;
}

/* function setOpInput(input) {
	document.getElementById('opinput').value=input;
	setOp('add');
} */

function setOpInput(input,action) {
	document.getElementById('opinput').value=input;
	setOp(action);
}

function setOpInputBelongsToFormsub(id) {
	document.getElementById('opinputbelongstoformsub').value=id;
//	setOp('add');
}

function setOpInputBelongsToFormsubgroup(id) {
	document.getElementById('opinputbelongstoformsubgroup').value=id;
//	setOp('add');
}

function setOpInputBelongsToForm(id) {
	document.getElementById('opinputbelongstoform').value=id;
//	setOp('add');
}

function setOpInputBelongsToTextblock(id) {
	document.getElementById('opinputbelongstotextblock').value=id;
//	setOp('add');
}

function setOpInputBelongsToTextpart(id) {
	document.getElementById('opinputbelongstotextpart').value=id;
//	setOp('add');
}

function setOpOccurrence(occurr) {
	document.getElementById('opoccurrence').value=occurr;
}

function resetSel(inputid) {
	document.getElementById('sel'+inputid.replace('inputtext','')).options.selectedIndex=0;
	setOpId('');
	setOpName('');
	setOp('add');
} 

function resetInput(selid) {
	document.getElementById('inputtext'+selid.replace('sel','')).value='';
	setOpInput('','remove');
//	document.getElementById('cat'+selid.replace('sel','')+'belongstoformsub').options.selectedIndex=0;
//	document.getElementById('cat'+selid.replace('sel','')+'belongstoform').options.selectedIndex=0;
//	setOp('remove');
}

function setOpTable(catnum) {
	document.getElementById('optable').value=catTables[catnum-1];
}

function checkFormInput(table,op,opinput) {
	var submitval;
	if(op=='add' || op=='update') {
		if(opinput!='') {
			if(table=='typo_subtypesformal') {
				if(document.getElementById('opinputbelongstoform').value!='') {
					submitval=1;
				}
				else {
					alert('Choose corresponding formal type first!');
					submitval=0;
				}
			}
			else if(table=='typo_textblocks') {
				if(document.getElementById('opinputbelongstoformsub').value!='') {
					submitval=1;
				}
				else {
					alert('Choose corresponding formal subtype first!');
					submitval=0;
				}
			}
			else if(table=='typo_textparts') {
				if(document.getElementById('opinputbelongstotextblock').value!='') {
					submitval=1;
				}
				else {
					alert('Choose corresponding text block first!');
					submitval=0;
				}
			}
			else if(table=='typo_phrases' && document.getElementById('opphrasekind').value=='keyphr') {
				if(document.getElementById('opinputbelongstotextpart').value!='') {
					submitval=1;
				}
				else {
					alert('Choose corresponding textpart first!');
					submitval=0;
				}
			}
			else {
				submitval=1;
			}
		}
		else {
			alert('Missing input!');
			submitval=0;
		}
	}
	else if(op=='remove') {
		submitval=confirm('Sure you want to remove this element and its dependencies?');
//		submitval=1;
	}
	else if(op=='connect') {
			if(document.getElementById('opinputbelongstoformsubgroup').value!='') {
				submitval=confirm('Make sure that subtype and subtype group belong to the same formal type!');
			}
			else {
				alert('Choose formal subtype group first!');
				submitval=0;
			}
	}
	else {
		alert('Missing input!');
		submitval=0;
	}
	if(submitval==1) {
		return true;
	}
	else {
		return false;
	}
}


/////////////
