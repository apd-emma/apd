function setDocName(name) {
	document.getElementById('').value='';
}


// docparts //

function setDocPart(docpart) {
	for(i=0;i<document.docform["docparts[]"].length;i++) {
		if(document.docform["docparts[]"][i].checked) {
			document.getElementById('docpart').value=document.docform["docparts[]"][i].id;
		}
	}
	document.getElementById('docpartstarted').value=0;
}

function applyDocPart(id) {
	var docpart = document.getElementById('docpart').value;
	var textbuttons = document.getElementById('buttontext').children; 
	var brCount = 0; 
	for(i=0;i<textbuttons.length;i++) {
			if(textbuttons[i].tagName=='BR') {
				brCount++;
			}
	}
//	alert('brCount: '+brCount);
	for(i=0;i<textbuttons.length-brCount;i++) {
		if(i+1>=id) {
//			alert(i + ": " + textbuttons[i].value);
			if(document.getElementById('docpartstarted').value==0) {
				document.getElementById('docpartstarted').value=1;
				document.getElementById(id).className=docpart;
			}
			if(document.getElementById('docpartstarted').value==1) {
				document.getElementById(i+1).className=docpart;
			}
//			alert(i + ": " + textbuttons[i].value);
		}
	}
}

// phrases //

function applyPhrases(id) {
	if(document.getElementById('freephrase').value!='') {
		applyFreePhrase(id);
	}
	if(document.getElementById('keyphrase').value!='') {
		applyKeyPhrase(id);
	}
}

function setFreePhrase(fphrase) {
	document.getElementById('freephrase').value=fphrase;	
//	document.getElementById('docpart').value='';
	document.docform.keyphrsel.selectedIndex=0;
	document.getElementById('keyphrase').value='';	
}

function setKeyPhrase(kphrase) {
	document.getElementById('keyphrase').value=kphrase;	
	document.docform.frphrsel.selectedIndex=0;
	document.getElementById('freephrase').value='';	
//	document.getElementsByName('frphrsel[]').selectedIndex=1;
}

function applyFreePhrase(id) {
	document.getElementById(id).className += ' freephr';
	//document.getElementById('freephrase').value='';	
}

function applyKeyPhrase(id) {
	document.getElementById(id).className += ' keyphr';
	//document.getElementById('keyphrase').value='';	
}

/////////////
